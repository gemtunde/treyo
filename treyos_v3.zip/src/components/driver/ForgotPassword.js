import ReuseForgotPassword from "../reuse/authentication/ForgotPassword";

const ForgotPassword = (props) => {
  return (
    <>
      <ReuseForgotPassword type="driver" />
    </>
  )
}

export default ForgotPassword;