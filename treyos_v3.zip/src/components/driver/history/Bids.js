import Home from "../../reuse/dashboard/history/Bids";

const Component = (props) => {
  return (
    <>
      <Home type="driver" />
    </>
  )
}

export default Component;