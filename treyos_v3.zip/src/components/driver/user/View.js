import View from "../../reuse/dashboard/user/View";

const Component = (props) => {
  return (
    <>
      <View type="driver" />
    </>
  )
}

export default Component;