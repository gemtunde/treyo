import React,{useState} from 'react';
import VerifyAccount from "../../reuse/setting/VerifyAccount";

const Component = (props) => {
  return (
    <>
      <VerifyAccount type="driver" />
    </>
  )
}

export default Component;