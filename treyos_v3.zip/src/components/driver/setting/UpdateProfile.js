import React,{useState} from 'react';
import UpdateProfile from "../../reuse/setting/UpdateProfile";

const Component = (props) => {
  return (
    <>
      <UpdateProfile type="driver" />
    </>
  )
}

export default Component;