import ReuseVerifyAccount from "../reuse/authentication/VerifyAccount";

const VerifyAccount = (props) => {
  return (
    <>
      <ReuseVerifyAccount type="driver" />
    </>
  )
}

export default VerifyAccount;