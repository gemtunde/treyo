import {useState} from 'react';
import Home from "../../reuse/dashboard/orders/Home";

const Component = (props) => {
  return (
    <>
      <Home type="driver" />
    </>
  )
}

export default Component;