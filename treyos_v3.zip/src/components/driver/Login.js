import ReuseLogin from "../reuse/authentication/Login";

const Login = (props) => {
  return (
    <>
      <ReuseLogin type="driver" />
    </>
  )
}

export default Login;