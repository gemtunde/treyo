import React,{useState} from 'react';
import Home from "../../reuse/dashboard/card/Home";

const Component = (props) => {
  return (
    <>
      <Home type="driver" />
    </>
  )
}

export default Component;