import ReuseResetPassword from "../reuse/authentication/ResetPassword";

const ResetPassword = (props) => {
  return (
    <>
      <ReuseResetPassword type="driver" />
    </>
  )
}

export default ResetPassword;