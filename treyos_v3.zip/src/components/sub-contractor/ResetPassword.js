import ReuseResetPassword from "../reuse/authentication/ResetPassword";

const ResetPassword = (props) => {
  return (
    <>
      <ReuseResetPassword type="sub-contractor"/>
    </>
  )
}

export default ResetPassword;