import ReuseForgotPassword from "../reuse/authentication/ForgotPassword";

const ForgotPassword = (props) => {
  return (
    <>
      <ReuseForgotPassword type="sub-contractor" />
    </>
  )
}

export default ForgotPassword;