import Home from "../../reuse/dashboard/history/Home";

const Component = (props) => {
  return (
    <>
      <Home type="sub-contractor" />
    </>
  )
}

export default Component;