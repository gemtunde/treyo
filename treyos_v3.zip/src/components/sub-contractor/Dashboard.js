import Dashboard from "../reuse/Dashboard";

const SubContractorDashboard =  (props) => {


    return (
      <>
        <Dashboard type="sub-contractor" active="overview"  />
      </>
    )
  
}

export default SubContractorDashboard;