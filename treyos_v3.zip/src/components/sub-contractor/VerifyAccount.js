import ReuseVerifyAccount from "../reuse/authentication/VerifyAccount";

const VerifyAccount = (props) => {
  return (
    <>
      <ReuseVerifyAccount type="sub-contractor" />
    </>
  )
}

export default VerifyAccount;