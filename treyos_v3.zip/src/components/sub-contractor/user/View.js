import View from "../../reuse/dashboard/user/View";

const Component = (props) => {
  return (
    <>
      <View type="sub-contractor" />
    </>
  )
}

export default Component;