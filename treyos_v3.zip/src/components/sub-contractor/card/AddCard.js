import AddCard from "../../reuse/dashboard/card/AddCard";

const Component = (props) => {
  return (
    <>
      <AddCard type="sub-contractor" />
    </>
  )
}

export default Component;