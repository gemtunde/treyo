import ReuseLogin from "../reuse/authentication/Login";

const Login = (props) => {


  return (
    <>
      <ReuseLogin type="sub-contractor" />
    </>
  )
}

export default Login;