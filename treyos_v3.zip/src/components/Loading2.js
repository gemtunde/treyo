export const Loading2 = (props) => {


  return (
    <>
       <div className="spinner-grow" role="status"></div>
    </>
  )
}

