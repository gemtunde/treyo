export const increment = () => {
	return {
		type: "INCREMENT"
	}
}

export const decrement = () => {
	return {
		type: "DECREMENT"
	}
}


export const saveNewRegistration = (payload) => {
	return {
		type: "SAVE_NEW_REGISTER",
		payload: payload
	}
}


export const saveUserData = (payload) => {
	return {
		type: "SAVE_USER_DATA",
		payload: payload
	}
}



export const saveResueData = (payload) => {
	return {
		type: "SAVE_REUSE_DATA",
		payload: payload
	}
}


export const viewUserData = (payload) => {
	return {
		type: "VIEW_USER_DATA",
		payload: payload
	}
}


export const saveCurrentLocation = (payload) => {
	return {
		type: "SAVE_CURRENT_LOCATION",
		payload: payload
	}
}


